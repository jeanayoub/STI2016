<html>
<head></head>
<body> "ici salut<br/>"
<?php
echo "salut";
?>
</body>
</html>
